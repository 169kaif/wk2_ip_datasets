#!/bin/sh
#$ -S /bin/bash
#$ -v PATH=:/opt/cd-hit:/opt/cd-hit/cd-hit-auxtools:/opt/cd-hit/psi-cd-hit:/opt/ncbi-blast-2.8.1+/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin



#$ -e /opt/data/1694246079/1694246079.err
#$ -o /opt/data/1694246079/1694246079.out
cd /opt/data/1694246079
sed -i "s/\x0d/\n/g" 1694246079.fas.0

faa_stat.pl 1694246079.fas.0

/opt/cd-hit/cd-hit -i 1694246079.fas.0 -d 0 -o 1694246079.fas.1 -c 0.4 -n 2  -G 1 -g 1 -b 20 -l 10 -s 0.0 -aL 0.0 -aS 0.0 -T 4 -M 32000
faa_stat.pl 1694246079.fas.1
/opt/cd-hit/clstr_sort_by.pl no < 1694246079.fas.1.clstr > 1694246079.fas.1.clstr.sorted
/opt/cd-hit/clstr_list.pl 1694246079.fas.1.clstr 1694246079.clstr.dump
gnuplot1.pl < 1694246079.fas.1.clstr > 1694246079.fas.1.clstr.1; gnuplot2.pl 1694246079.fas.1.clstr.1 1694246079.fas.1.clstr.1.png
/opt/cd-hit/clstr_list_sort.pl 1694246079.clstr.dump 1694246079.clstr_no.dump
/opt/cd-hit/clstr_list_sort.pl 1694246079.clstr.dump 1694246079.clstr_len.dump len
/opt/cd-hit/clstr_list_sort.pl 1694246079.clstr.dump 1694246079.clstr_des.dump des
tar -zcf 1694246079.result.tar.gz * --exclude=*.dump --exclude=*.env
echo hello > 1694246079.ok
